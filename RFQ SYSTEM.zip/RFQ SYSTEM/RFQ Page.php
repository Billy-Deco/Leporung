<?php
	session_start();
	$location = 'index.php';
	$location1 = 'RFQ Sub Menu.php';
	$dbServer = 'localhost';
	$dbName = 'Leporung_Pro';
	
	//Input Variable
	$project_no = '';
	$entity = '';
	$description = '';
	$request_Date = '';
	$deadline_Date = '';
	$completion_Date = '';
	$username = '';
	
	//Boolean Values
	$validEntity = false;
	$validRequest = false;
	$validDeadline = false;
	$valid_dates = false;
	$expired = true;
	$error_message = '';
	
	if(isset($_SESSION['Username'])){
		
		//Code For Save Button
		if(isset($_POST['Save'])){
			
			//RFQ Project Number
			if(isset($_POST['Project_No'])){
				$project_no = $_POST['Project_No'];
			}
			
			//RFQ Project Entity
			if(isset($_POST['Entity'])){
				$entity = $_POST['Entity'];
			}
			
			//RFQ Project Description
			if(isset($_POST['Description'])){
				$description = $_POST['Description'];
			}
			
			//RFQ Project Request Date
			if(isset($_POST['Request_Date'])){
				$request_Date = $_POST['Request_Date'];
			}
			
			//RFQ Project Deadline Date
			if(isset($_POST['Deadline_Date'])){
				$deadline_Date = $_POST['Deadline_Date'];
			}
			
			//Product_1 
			if(isset($_POST['PD1'])){
				$product_1 = $_POST['PD1'];
			}
			if(isset($_POST['PQ1'])){
				$quantity_1 = $_POST['PQ1'];
			}
			
			//Product_2 
			if(isset($_POST['PD2'])){
				$product_2 = $_POST['PD2'];
			}
			if(isset($_POST['PQ2'])){
				$quantity_2 = $_POST['PQ2'];
			}
			
			//Product_3 
			if(isset($_POST['PD3'])){
				$product_3 = $_POST['PD3'];
			}
			if(isset($_POST['PQ3'])){
				$quantity_3 = $_POST['PQ3'];
			}
			
			//Product_4 
			if(isset($_POST['PD4'])){
				$product_4 = $_POST['PD4'];
			}
			if(isset($_POST['PQ4'])){
				$quantity_4 = $_POST['PQ4'];
			}
			
			//Product_5 
			if(isset($_POST['PD5'])){
				$product_5 = $_POST['PD5'];
			}
			if(isset($_POST['PQ5'])){
				$quantity_5 = $_POST['PQ5'];
			}
			
			//Product_6 
			if(isset($_POST['PD6'])){
				$product_6 = $_POST['PD6'];
			}
			if(isset($_POST['PQ6'])){
				$quantity_6 = $_POST['PQ6'];
			}
			
			//Product_7
			if(isset($_POST['PD7'])){
				$product_7 = $_POST['PD7'];
			}
			if(isset($_POST['PQ7'])){
				$quantity_7 = $_POST['PQ7'];
			}
			
			//Product_8 
			if(isset($_POST['PD8'])){
				$product_8 = $_POST['PD8'];
			}
			if(isset($_POST['PQ8'])){
				$quantity_8 = $_POST['PQ8'];
			}
			
			//Product_9 
			if(isset($_POST['PD9'])){
				$product_9 = $_POST['PD9'];
			}
			if(isset($_POST['PQ9'])){
				$quantity_9 = $_POST['PQ9'];
			}
			
			//Product_10 
			if(isset($_POST['PD10'])){
				$product_10 = $_POST['PD10'];
			}
			if(isset($_POST['PQ10'])){
				$quantity_10 = $_POST['PQ10'];
			}
			
			//Product_11
			if(isset($_POST['PD11'])){
				$product_11 = $_POST['PD11'];
			}
			if(isset($_POST['PQ11'])){
				$quantity_11 = $_POST['PQ11'];
			}
			
			//Product_12 
			if(isset($_POST['PD12'])){
				$product_12 = $_POST['PD12'];
			}
			if(isset($_POST['PQ12'])){
				$quantity_12 = $_POST['PQ12'];
			} 
			
			//Product_13 
			if(isset($_POST['PD13'])){
				$product_13 = $_POST['PD13'];
			}
			if(isset($_POST['PQ13'])){
				$quantity_13 = $_POST['PQ13'];
			}
			
			//Product_14 
			if(isset($_POST['PD14'])){
				$product_14 = $_POST['PD14'];
			}
			if(isset($_POST['PQ14'])){
				$quantity_14 = $_POST['PQ14'];
			}
			
			//Product_15 
			if(isset($_POST['PD15'])){
				$product_15 = $_POST['PD15'];
			}
			if(isset($_POST['PQ15'])){
				$quantity_15 = $_POST['PQ15'];
			}
			
			//--------------------Input Validation-------------------
			
			//Validate Project Number
			if(!empty($project_no)){
				$validProject_No = true;
			}else{
				$validProject_No = false;
			}
			
			//Validate Entity
			if(!empty($entity)){
				$validEntity = strValidate($entity);
			}else{
				$error_message = "Required Entity Field.";
			}
			
			//Validate Description
			if(!empty($description)){
				$validDesc = true;
			}else{
				$validDesc = false;
			}
			
			//Validate Request Date
			if(!empty($request_Date)){
				$validRequest = validateDate($request_Date);
			}else{
				$error_message = "Required Request Date Field.";
			}
			
			//Validate Deadline Date
			if(!empty($deadline_Date)){
				$validRequest = validateDate($deadline_Date);
				if($validRequest){
					$expired = expiredProject($deadline_Date);
				}else{
					$error_message = "Project Already Expired.";
				}
			}else{
				$error_message = "Required Request Date Field.";
			}
			
			//Validate Product 1
			if(!empty($product_1) && !empty($quantity_1)){
				$validQty_1 = dgtValidate($quantity_1);
			}
			
			//Validate Product 2
			if(!empty($product_2) && !empty($quantity_2)){
				$validQty_2 = dgtValidate($quantity_2);
			}
			
			//Validate Product 3
			if(!empty($product_3) && !empty($quantity_3)){
				$validQty_3 = dgtValidate($quantity_3);
			}
			
			//Validate Product 4
			if(!empty($product_4) && !empty($quantity_4)){
				$validQty_4 = dgtValidate($quantity_4);
			}
			
			//Validate Product 5
			if(!empty($product_5) && !empty($quantity_5)){
				$validQty_5 = dgtValidate($quantity_5);
			}
			
			//Validate Product 6
			if(!empty($product_6) && !empty($quantity_6)){
				$validQty_6 = dgtValidate($quantity_6);
			}
			
			//Validate Product 7
			if(!empty($product_7) && !empty($quantity_7)){
				$validQty_7 = dgtValidate($quantity_7);
			}
			
			//Validate Product 8
			if(!empty($product_8) && !empty($quantity_8)){
				$validQty_8 = dgtValidate($quantity_8);
			}
			
			//Validate Product 9
			if(!empty($product_9) && !empty($quantity_9)){
				$validQty_9 = dgtValidate($quantity_9);
			}
			
			//Validate Product 10
			if(!empty($product_10) && !empty($quantity_10)){
				$validQty_10 = dgtValidate($quantity_10);
			}
			
			//Validate Product 11
			if(!empty($product_11) && !empty($quantity_11)){
				$validQty_11 = dgtValidate($quantity_11);
			}
			
			//Validate Product 12
			if(!empty($product_12) && !empty($quantity_12)){
				$validQty_12 = dgtValidate($quantity_12);
			}
			
			//Validate Product 13
			if(!empty($product_13) && !empty($quantity_13)){
				$validQty_13 = dgtValidate($quantity_13);
			}
			
			//Validate Product 14
			if(!empty($product_14) && !empty($quantity_14)){
				$validQty_14 = dgtValidate($quantity_14);
			}
			
			//Validate Product 15
			if(!empty($product_15) && !empty($quantity_15)){
				$validQty_15 = dgtValidate($quantity_15);
			}
			
			//---------------------------Save Information-----------------------
			
			if($validProject_No){
				if($validEntity){
					if($validDesc){
						if($validRequest){
							if(!$expired){
								$validDates = datesValid($request_Date, $deadline_Date);
								if($validDates){
									
									$username = $_SESSION["Username"];
									
									$conn = mysqli_connect($dbServer, 'root', 'TeeRay.1', $dbName);
									if(!$conn){
										$error_message = 'Cannot Connect to Database.';
										die('Connection Failed.');
									}
												
									$sql1 = "SELECT * FROM rfq_project_2020";
									$results = mysqli_query($conn, $sql1);
									$resultCheck = mysqli_num_rows($results);
												
									if($resultCheck > 0){
													
										while($row = mysqli_fetch_assoc($results)){
														
											if(($row['Project_No'] == $project_no) && ($row['Entity'] == $entity) && ($row['Description'] == $description) && ($row['Request_Date'] == $request_Date) && ($row['Deadline_Date'] == $deadline_Date)){
												$save = false;
											}else{
												$save = true;
											}
										}
													
									}else{
										$save = true;
									}
									
									if($save){
													
										$sql = "INSERT INTO leporung_pro.rfq_project_2020(Project_No, Entity, Description, Request_Date, Deadline_Date, Username) 
											VALUES('".$project_no."', '".$entity."', '".$description."', '".$request_Date."', '".$deadline_Date."', '".$username."')";
													
										$resultsSave = mysqli_query($conn, $sql);
													
										if($resultsSave){
											$error_message = "Record Saved Successfully.";
											mysqli_close();
										}else{
											$error_message = "Record Not Saved.";
											mysqli_close($conn);
										}
													
									}else{
										$error_message = "Record Already Exists.";
									}
									
								}else{
									$error_message = "Request Date cannot be older then Deadline Date.";
								}
							}else{
								$error_message = "Project Already Expired.";
							}
						}else{
							$error_message = "Invalid Request Date.";
						}
					}else{
						$error_message = "Required Description Field.";
					}
				}else{
					$error_message = "Entity Must be In Text Format.";
				}
			}else{
				$error_message = "Required Project Number Field.";
			}

		}
		
		//Preview Button Pressed
		if(isset($_POST['Clear All'])){
			
		}
		
		//Back Button Pressed
		if(isset($_POST['Back'])){
			
			header('Location:' .$location1);
			
		}
		
//========================================End Of Code==============================================================		
	}else{
		header('Location:' .$location);	
	}
	
//------------------------------------------------Validation Functions---------------------------------------------------------------------------
	//Function to Validate String Inputs
	function strValidate($strValue){
		$strValid = false;
		
		if (preg_match("/^[a-zA-Z ]+$/",$strValue)){
			$strValid = true;
		}else{
			$strValid = false;	
		}
		
		return $strValid;
	}
	
	//Function to Validate Digit inputs
	function dgtValidate($dgtValue){
		$dgtValid = false;
		
		if (preg_match("/^[0-9]*$/",$dgtValue)){
			$dgtValid = true;
		}else{
			$dgtValid = false;	
		}
		
		return $dgtValid;
	}
	
	//Function to Validate date Input
	function validateDate($value){
		$dateValid = false;
		
		if(date('Y/m/d', strtotime($value)) == $value || date('Y-m-d', strtotime($value)) == $value){
			$dateValid = true;
		}else{
			$dateValid = false;	
		}
		
		return $dateValid;
	}
	
	//Function to Determine Expiration
	function expiredProject($date){
		$today = strtotime(date('Y/m/d'));
		$deadline_date = strtotime($date);
		
		if($today > $deadline_date)//check whether the deadline has passed
		{
			$expired = true;
		}
		else if($today == $deadline_date)
		{
			$expired = false;
		}
		else
		{
			$expired = false;
		}
		
		return $expired;
	}
	
	//Function for Invalid Dates
	function datesValid($req_date, $due_date){
		
		$start_date = strtotime($req_date);
		$end_date = strtotime($due_date);
		
		if(($end_date) > ($start_date)){
			$datesValid = true;	
		}else{
			$datesValid = false;	
		}
		
		return $datesValid;
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	
	<div id="Page">

        <!--Logo Div Properties-->
        <div id="Heading">
			<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
        	<div>NEW RFQ PROJECT</div>
        </div>
        
        <!--View RFQ Properties-->
        <div id="Division">
        	<form action="RFQ Page.php" method="post">
            	<table align="center">
					<tr>
						<td colspan="2" id="tableHeader"><?php echo $_SESSION["Username"]; ?></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><img src="images/Admin_PNG.png" id="Admin_Image" alt="Admin_Image" width="150px" height="100px"></td>
					</tr>
					 <tr>
                    	<td id="indexLabel">Project Number: </td>
                        <td><input type="text" name="Project_No" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Entity/Supplier: </td>
                        <td><input type="text" name="Entity" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Description: </td>
                        <td><input type="text" name="Description" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Request Date: </td>
                        <td><input type="text" name="Request_Date" size="12" id="inputCSS" placeholder="(YYYY/MM/DD)"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Deadline Date: </td>
                        <td><input type="text" name="Deadline_Date" size="12" id="inputCSS" placeholder="(YYYY/MM/DD)"></td>
                    </tr>
					<tr>
						<td colspan="6" align="center"><?php echo $error_message; ?></td>
					</tr>
                </table> 
        </div>
		
		<!--Display Division-->
        <div id="Division">
        	<table align="center" class="table">
				<tr>
					<td id='tableHeader'>Item #</td>
					<td id='tableHeader'>Product Description</td>
					<td id='tableHeader'>Qty</td>
					<td id='tableHeader'>Item Price</td>
				</tr>
				<tr>
					<td align="center">1.</td>
					<td><input type="text" name="PD1" class="P_Desc" /></td>
					<td><input type="text" name="PQ1" class="unit"/></td>
					<td><input type="text" name="PUP1" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">2.</td>
					<td><input type="text" name="PD2" class="P_Desc" /></td>
					<td><input type="text" name="PQ2" class="unit"/></td>
					<td><input type="text" name="PUP2" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">3.</td>
					<td><input type="text" name="PD3" class="P_Desc" /></td>
					<td><input type="text" name="PQ3" class="unit"/></td>
					<td><input type="text" name="PUP3" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">4.</td>
					<td><input type="text" name="PD4" class="P_Desc" /></td>
					<td><input type="text" name="PQ4" class="unit"/></td>
					<td><input type="text" name="PUP4" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">5.</td>
					<td><input type="text" name="PD5" class="P_Desc" /></td>
					<td><input type="text" name="PQ5" class="unit"/></td>
					<td><input type="text" name="PUP5" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">6.</td>
					<td><input type="text" name="PD6" class="P_Desc" /></td>
					<td><input type="text" name="PQ6" class="unit"/></td>
					<td><input type="text" name="PUP6" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">7.</td>
					<td><input type="text" name="PD7" class="P_Desc" /></td>
					<td><input type="text" name="PQ7" class="unit"/></td>
					<td><input type="text" name="PUP7" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">8.</td>
					<td><input type="text" name="PD8" class="P_Desc" /></td>
					<td><input type="text" name="PQ8" class="unit"/></td>
					<td><input type="text" name="PUP8" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">9.</td>
					<td><input type="text" name="PD9" class="P_Desc" /></td>
					<td><input type="text" name="PQ9" class="unit"/></td>
					<td><input type="text" name="PUP9" class="unitPrice" /></td>
				</tr>
				<tr>
					<td align="center">10.</td>
					<td><input type="text" name="PD10" class="P_Desc" /></td>
					<td><input type="text" name="PQ10" class="unit"/></td>
					<td><input type="text" name="PUP10" class="unitPrice" /></td>
				</tr>
				<tr>
					<td colspan="3" align="center" id="buttonholder"><input type="submit" name="Save" value="Save" id="button">
                    <input type="reset" name="Clear All" value="Clear All" id="button"/>
                    <input type="submit" name="Back" value="Back" id="button"/></td>
				</tr>
        	</table>
			</form>
        </div>
        
        <!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div>
</body>
</html>
