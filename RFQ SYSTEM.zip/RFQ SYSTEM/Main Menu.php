<?php
	session_start();
	$location = 'index.php';
	$location1 = 'RFQ Sub Menu.php';
	$location2 = 'Purchase Order Menu.php';
	$location3 = 'Employee Details Menu.php';
	$location4 = 'Supplier Details Menu.php';
	$dbServer = 'localhost';
	$dbName = 'Leporung_Pro';
	
	if(isset($_SESSION['Username'])){
		
		//RFQ Page Button
		if(isset($_POST['REQUEST_FOR_QUOTATION'])){
			
			header('Location:' .$location1);	
			
		}
		
		//Purchase_Order Button Pressed
		if(isset($_POST['PURCHASE_ORDER'])){
			
			header('Location:' .$location2);	
			
		}
		
		//Supplier_Details Button Pressed
		if(isset($_POST['SUPPLIER_DETAILS'])){
			
			header('Location:' .$location4);
			
		}
		
		//Employee Registration Button Pressed
		if(isset($_POST['EMPLOYEE_DETAILS'])){
			
			header('Location:' .$location3);
			
		}
		
		//Logout Button Pressed
		if(isset($_POST['LOGOUT'])){
			
			$_SESSION['Username'] = "";
			header('Location:' .$location);
			
		}
		
//========================================End Of Code==============================================================		
	}else{
		header('Location:' .$location);	
	}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	
	<div id="Page">

		<!--Display Division-->
        <div id="Division">
        	
			<!--Logo Div Properties-->
			<div id="Heading">
				<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
				<div>MAIN MENU</div>
			</div>
			
			<form action="Main Menu.php" method="POST">
				<table align="center">
					<tr>
						<td width="350px" height="30px"><input type="submit" name="REQUEST_FOR_QUOTATION" value="REQUEST FOR QUOTATION" id="button_css" height="100px"></td>
					</tr>
					<tr>
						<td width="350px" height="30px"><input type="submit" name="PURCHASE_ORDER" value="PURCHASE ORDER" id="button_css"></td>
					</tr>
					<tr>
						<td width="350px" height="30px"><input type="submit" name="SUPPLIER_DETAILS" value="SUPPLIER DETAILS" id="button_css"></td>
					</tr>
					<tr>
						<td width="350px" height="30px"><input type="submit" name="EMPLOYEE_DETAILS" value="EMPLOYEE DETAILS" id="button_css"></td>
					</tr>
					<tr>
						<td width="350px" height="30px"><input type="submit" name="LOGOUT" value="LOGOUT" id="button_css"></td>
					</tr>
				</table>
			</form>
			
        </div>
        
        <!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div>
</body>
</html>
