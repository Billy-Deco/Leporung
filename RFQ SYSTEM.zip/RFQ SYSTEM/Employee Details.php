<?php
	session_start();
	$location = 'index.php';
	$location1 = 'Employee Details Menu.php';
	$dbServer = 'localhost';
	$dbName = 'leporung_pro';
	
	//Variable Declaration
	$initials = '';
	$surname = '';
	$id_No = '';
	$occupation = '';
	$street = '';
	$town = '';
	$city = '';
	$postal_Code = '';
	$cell_No = '';
	$email = '';
	$username = '';
	$password = '';
	$confirm = '';
	$error_message = '';
	
	//Validation Variables
	$validInitials = '';
	$validSurname = '';
	$validID_Type = '';
	$validID_No = '';
	$validOccupation = '';
	$validStreet = '';
	$validTown = '';
	$validCity = '';
	$validPostal_Type = '';
	$validPostal = '';
	$validCell_Type = '';
	$validCell_No = '';
	$validEmail = '';
	$validPassword = '';
	$validConfirm = '';
	
	if(isset($_SESSION['Username'])){
		
		//Code For Save Button
		if(isset($_POST['Save'])){
			
			if(isset($_POST['Initials'])){
				$initials = $_POST['Initials'];
			}
			
			if(isset($_POST['Surname'])){
				$surname = $_POST['Surname'];
			}
			
			if(isset($_POST['ID'])){
				$id_No = $_POST['ID'];
			}
			
			if(isset($_POST['Occupation'])){
				$occupation = $_POST['Occupation'];
			}
			
			if(isset($_POST['Street'])){
				$street = $_POST['Street'];
			}
			
			if(isset($_POST['Town'])){
				$town = $_POST['Town'];
			}
			
			if(isset($_POST['City'])){
				$city = $_POST['City'];
			}
			
			if(isset($_POST['Postal_Code'])){
				$postal_code = $_POST['Postal_Code'];
			}
			
			if(isset($_POST['Name'])){
				$contact_name = $_POST['Name'];
			}
			
			if(isset($_POST['Cell_No'])){
				$cell_no = $_POST['Cell_No'];
			}
			
			if(isset($_POST['Email'])){
				$email = $_POST['Email'];
			}
			
			if(isset($_POST['Username'])){
				$username = $_POST['Username'];
			}
			
			if(isset($_POST['Password'])){
				$password = $_POST['Password'];
			}
			
			if(isset($_POST['Confirm'])){
				$confirm = $_POST['Confirm'];
			}
			
			//----------------------------------Validation Check---------------------
			
			//Validate Initials Input
			if(!empty($initials)){
				$validInitials = strValidate($initials);
			}else{
				$error_message = "Required Initials Field.";
			}
			
			if(!empty($surname)){
				$validSurname = strValidate($surname);
			}else{
				$error_message = "Required Surname Field.";
			}
			
			//Validate ID Number
			if(!empty($id_No)){
				$validID_Type = dgtValidate($id_No);
				if($validID_Type){
					$validId_No = validID($id_No);
				}else{
					$error_message = "ID Number Field should be in number format.";
				}
			}else{
				$error_message = "Required ID Number Field.";
			}
			
			//Validate Occupation Input
			if(!empty($occupation)){
				$validOccupation = strValidate($occupation);
			}else{
				$error_message = "Required Occupation Field.";
			}
			
			//Validate Address Field
			if(!empty($street)){
				$validStreet = true;
			}else{
				$error_message = "Required Street Address Field.";
			}
			
			if(!empty($town)){
				$validTown = strValidate($town);
			}else{
				$error_message = "Required Town Field.";
			}
			
			if(!empty($city)){
				$validCity = strValidate($city);
			}else{
				$error_message = "Required City Field.";
			}
			
			if(!empty($postal_code)){
				$validPostal_Type = dgtValidate($postal_code);
				if($validPostal_Type){
					$validPostal = valiPostal($postal_code);
				}else{
					$error_message = "Postal Code should be in number format.";
				}
			}else{
				$error_message = "Required Postal Code Field.";
			}
			
			//Validate Cell Number
			if(!empty($cell_no)){
				$validCell_Type = dgtValidate($cell_no);
				if($validCell_Type){
					$validCell_No = validCell($cell_no);
				}else{
					$error_message = "Cell Number Field should be in number format.";
				}
			}else{
				$error_message = "Required Cell Number Field.";
			}
			
			//Validate Email field
			if(!empty($email)){
				$validEmail = validEmail($email);
			}else{
				$error_message = "Required Email Field.";
			}
			
			//Validate Password
			if(!empty($password)){
				$validPassword = true;
			}else{
				$error_message = "Required Password Field.";
			}
			
			//Validate Confirm
			if(!empty($confirm)){
				$validConfirm = true;
			}else{
				$error_message = "Required Confirm Field.";
			}
			
			//-----------------------------Save Information--------------
			if($validInitials){
				if($validSurname){
					if($validId_No){
						if($validOccupation){
							if($validStreet){
								if($validTown){
									if($validCity){
										if($validPostal){
											if($validCell_No){
												if($validEmail){
													if($password == $confirm){
														
														$conn = mysqli_connect($dbServer, 'root', 'TeeRay.1', $dbName);
														if(!$conn){
															$error_message = 'Cannot Connect to Database.';
															die('Connection Failed.');
														}
														
														$sql = "SELECT * FROM leporung_pro_employee_details_2020";
														$results = mysqli_query($conn, $sql);
														$resultCheck = mysqli_num_rows($results);
														
														if($resultCheck > 0){
															
															while($row = mysqli_fetch_assoc($results)){
																
																if(($row['Initials'] == $initials) && ($row['Surname'] == $surname) && ($row['ID_NO'] == $id_No) && ($row['Occupation'] == $occupation) && ($row['Street'] == $street) && ($row['Town'] == $town) && ($row['City'] == $city) && ($row['Postal_Code'] == $postal_code) && ($row['Cell_Number'] == $cell_no) && ($row['Email'] == $email) && ($row['Username'] == $username) && ($row['Password'] == $password)){
																	$save = false;
																}else{
																	$save = true;
																}
															}
															
														}else{
															$save = true;
														}
														
														if($save){
															
															$sql = "INSERT INTO leporung_pro.leporung_pro_employee_details_2020(Initials, Surname, ID_NO, Occupation, Street, Town, City, Postal_Code, Cell_Number, Email, Username, Password)
																	VALUES('".$initials."', '".$surname."', '".$id_No."', '".$occupation."', '".$street."', '".$town."', '".$city."', '".$postal_code."', '".$cell_no."', '".$email."', '".$username."', '".$password."' )";
															
															$resultsSave = mysqli_query($conn, $sql);
															
															if($resultsSave){
																$error_message = "Record Saved Successfully.";
																mysqli_close();
															}else{
																$error_message = "Record Not Saved.";
																mysqli_close($conn);
															}
															
														}else{
															$error_message = "Record Already Exists.";
														} 
														
														
														
													}else{
														$error_message = "Password and Confirm are not the same.";
													}
												}else{
													$error_message = "Invalid Email.";
												}
											}else{
												$error_message = "Invalid Cell Number.";
											}
										}else{
											$error_message = "Postal Code should be 4 Digits.";
										}
									}else{
										$error_message = "City Field should be in text format.";
									}
								}else{
									$error_message = "Town Field should be in text format.";
								}
							}
						}else{
							$error_message = "Occupation should be in text format.";
						}
					}else{
						$error_message = "ID Number should be in number format.";
					}
				}else{
					$error_message = "Surname should be in text format.";
				}
			}else{
				$error_message = "Initials should be in text format.";
			}
			
		}
		
		//Preview Button Pressed
		if(isset($_POST['Clear All'])){
			
		}
		
		//Back Button Pressed
		if(isset($_POST['Back'])){
			
			header('Location:' .$location1);
			
		}
		
//========================================End Of Code==============================================================		
	}else{
		header('Location:' .$location);	
	}
	
//------------------------------------------------Validation Functions---------------------------------------------------------------------------
	//Function to Validate String Inputs
	function strValidate($strValue){
		$strValid = false;
		
		if (preg_match("/^[a-zA-Z ]+$/",$strValue)){
			$strValid = true;
		}else{
			$strValid = false;	
		}
		
		return $strValid;
	}
	
	//Function to Validate Digit inputs
	function dgtValidate($dgtValue){
		$dgtValid = false;
		
		if (preg_match("/^[0-9]*$/",$dgtValue)){
			$dgtValid = true;
		}else{
			$dgtValid = false;	
		}
		
		return $dgtValid;
	}
	
	//Function to Validate Postal Code
	function valiPostal($value){
		
		if(strlen($value) == 4){
			$validPostal = true;
		}else{
			$validPostal = false;
		}
		
		return $validPostal;
	}
	
	//Function to validate email
	function validEmail($value){
		
		if(filter_var($value, FILTER_VALIDATE_EMAIL)){
			$validEmail = true;
		}else{
			$validEmail = false;
		}
		
		return $validEmail;
	}
	
	//Function to Validate Phone Number
	function validCell($value){
		
		if(strlen($value) == 10){
			if(preg_match("/^[0]/", $value)){
				$cell_Check = true;
			}else{
				$cell_Check = false;
			}
		}else{
			$cell_Check = false;
		}
		
		return $cell_Check;
	}
	
	//function to Validate ID Number
	function validID($value){
		
		if(strlen($value) == 13){
			$validId = true;
		}else{
			$validId = false;
		}
		
		return $validId;
	}
	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	
	<div id="Page">
    	<!--Logo Div Properties-->
        <div id="Heading">
			<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
        	<div>NEW EMPLOYEE</div>
        </div>
        
        <!--View RFQ Properties-->
        <div id="Division">
        	<form action="Employee Details.php" method="post">
            	<table align="center">
                	<tr>
						<td colspan="2" id="tableHeader"><?php echo $_SESSION["Username"]; ?></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><img src="images/Admin_PNG.png" id="Admin_Image" alt="Admin_Image" width="150px" height="100px"></td>
					</tr>
                    <tr>
                    	<td id="indexLabel">Initials: </td>
                        <td><input type="text" name="Initials" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">Surname:</td>
                        <td><input type="text" name="Surname" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">ID Number:</td>
                        <td><input type="text" name="ID" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">Occupation:</td>
                        <td><input type="text" name="Occupation" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Address: </td>
                        <td><input type="text" name="Street" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td></td>
                        <td><input type="text" name="Town" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td></td>
                        <td><input type="text" name="City" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td></td>
                        <td align="right"><input type="text" name="Postal_Code" id="inputCSS" size="5"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">Cell Number: </td>
                        <td><input type="text" name="Cell_No" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">Email: </td>
                        <td><input type="text" name="Email" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">Username: </td>
                        <td><input type="text" name="Username" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">Password: </td>
                        <td><input type="password" name="Password" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">Confirm: </td>
                        <td><input type="password" name="Confirm" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
						<td colspan="2" align="center"><?php echo $error_message; ?></td>
					</tr>
                </table> 
				
				<table  align="center">
					<tr>
						<td><input type="submit" name="Save" value="Save" id="button">
						<input type="reset" name="Clear All" value="Clear All" id="button"/>
						<input type="submit" name="Back" value="Back" id="button"/></td>
					</tr>
				</table>
			</form>
        </div>

        <!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div>
</body>
</html>
