-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2020 at 07:28 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leporung_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `leporung_pro_employee_details_2020`
--

CREATE TABLE IF NOT EXISTS `leporung_pro_employee_details_2020` (
  `Project_ID` int(11) NOT NULL,
  `Initials` varchar(255) NOT NULL,
  `Surname` varchar(255) NOT NULL,
  `ID_NO` int(11) NOT NULL,
  `Occupation` varchar(255) NOT NULL,
  `Street` varchar(255) NOT NULL,
  `Town` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `Postal_Code` int(11) NOT NULL,
  `Cell_Number` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leporung_pro_supplier_details_2020`
--

CREATE TABLE IF NOT EXISTS `leporung_pro_supplier_details_2020` (
  `Project_ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `VAT_Number` int(11) NOT NULL,
  `Account_number` int(11) NOT NULL,
  `Branch_Code` varchar(255) NOT NULL,
  `Street` varchar(255) NOT NULL,
  `Town` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `Postal_Code` int(11) NOT NULL,
  `Contact_Name` varchar(255) NOT NULL,
  `Cell_Number` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_prices_2020`
--

CREATE TABLE IF NOT EXISTS `purchase_order_prices_2020` (
  `Project_ID` int(11) NOT NULL,
  `Project_No` int(11) NOT NULL,
  `Unit_Price_1` int(11) DEFAULT NULL,
  `Unit_Price_2` int(11) DEFAULT NULL,
  `Unit_Price_3` int(11) DEFAULT NULL,
  `Unit_Price_4` int(11) DEFAULT NULL,
  `Unit_Price_5` int(11) DEFAULT NULL,
  `Unit_Price_6` int(11) DEFAULT NULL,
  `Unit_Price_7` int(11) DEFAULT NULL,
  `Unit_Price_8` int(11) DEFAULT NULL,
  `Unit_Price_9` int(11) DEFAULT NULL,
  `Unit_Price_10` int(11) DEFAULT NULL,
  `Unit_Price_11` int(11) DEFAULT NULL,
  `Unit_Price_12` int(11) DEFAULT NULL,
  `Unit_Price_13` int(11) DEFAULT NULL,
  `Unit_Price_14` int(11) DEFAULT NULL,
  `Unit_Price_15` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_projects_2020`
--

CREATE TABLE IF NOT EXISTS `purchase_order_projects_2020` (
  `Project_ID` int(11) NOT NULL,
  `RFQ_Project_No` int(11) NOT NULL,
  `Project_No` int(11) NOT NULL,
  `Supplier` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Request_Date` date NOT NULL,
  `Deadline_Date` date NOT NULL,
  `Completion_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rfq_products_2020`
--

CREATE TABLE IF NOT EXISTS `rfq_products_2020` (
  `Project_ID` int(11) NOT NULL,
  `Project_No` int(11) NOT NULL,
  `Product_1` int(11) NOT NULL,
  `Quantity_1` int(11) NOT NULL,
  `Product_2` int(11) NOT NULL,
  `Quantity_2` int(11) NOT NULL,
  `Product_3` int(11) NOT NULL,
  `Quantity_3` int(11) NOT NULL,
  `Product_4` int(11) NOT NULL,
  `Quantity_4` int(11) NOT NULL,
  `Product_5` int(11) NOT NULL,
  `Quantity_5` int(11) NOT NULL,
  `Product_6` int(11) NOT NULL,
  `Quantity_6` int(11) NOT NULL,
  `Product_7` int(11) NOT NULL,
  `Quantity_7` int(11) NOT NULL,
  `Product_8` int(11) NOT NULL,
  `Quantity_8` int(11) NOT NULL,
  `Product_9` int(11) NOT NULL,
  `Quantity_9` int(11) NOT NULL,
  `Product_10` int(11) NOT NULL,
  `Quantity_10` int(11) NOT NULL,
  `Product_11` int(11) NOT NULL,
  `Quantity_11` int(11) NOT NULL,
  `Product_12` int(11) NOT NULL,
  `Quantity_12` int(11) NOT NULL,
  `Product_13` int(11) NOT NULL,
  `Quantity_13` int(11) NOT NULL,
  `Product_14` int(11) NOT NULL,
  `Quantity_14` int(11) NOT NULL,
  `Product_15` int(11) NOT NULL,
  `Quantity_15` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rfq_project_2020`
--

CREATE TABLE IF NOT EXISTS `rfq_project_2020` (
  `Project_ID` int(11) NOT NULL,
  `Project_No` varchar(225) NOT NULL,
  `Entity` varchar(225) NOT NULL,
  `Description` varchar(225) NOT NULL,
  `Request_Date` date NOT NULL,
  `Deadline_Date` date NOT NULL,
  `Username` varchar(15) NOT NULL,
  `Completion_Date` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rfq_project_2020`
--

INSERT INTO `rfq_project_2020` (`Project_ID`, `Project_No`, `Entity`, `Description`, `Request_Date`, `Deadline_Date`, `Username`, `Completion_Date`) VALUES
(1, 'Prj_SO3', 'Leporung Constructions and Supply', 'Product Supplier SO3 Plant Maintenance', '2020-09-10', '2020-09-20', 'admin', '2020-09-29'),
(2, 'BMD_No2', 'Bunny Media and Design', 'Test Run Number 2', '2020-09-15', '2020-10-01', 'admin', '2020-10-07'),
(3, 'SMD_No3', 'Leporung Pro', 'Test Run Number 3 of RFQ System', '2020-09-01', '2020-09-20', 'admin', NULL),
(4, 'PVR25', 'Rebellious Fox Designs', 'Media Design Industry', '2020-08-22', '2020-09-01', 'admin', NULL),
(5, 'Rmc1', 'Bunny entertainment', 'Management System Design', '2020-09-01', '2020-10-25', 'Billy', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leporung_pro_employee_details_2020`
--
ALTER TABLE `leporung_pro_employee_details_2020`
  ADD PRIMARY KEY (`Project_ID`);

--
-- Indexes for table `leporung_pro_supplier_details_2020`
--
ALTER TABLE `leporung_pro_supplier_details_2020`
  ADD PRIMARY KEY (`Project_ID`);

--
-- Indexes for table `purchase_order_prices_2020`
--
ALTER TABLE `purchase_order_prices_2020`
  ADD PRIMARY KEY (`Project_ID`);

--
-- Indexes for table `purchase_order_projects_2020`
--
ALTER TABLE `purchase_order_projects_2020`
  ADD PRIMARY KEY (`Project_ID`);

--
-- Indexes for table `rfq_products_2020`
--
ALTER TABLE `rfq_products_2020`
  ADD PRIMARY KEY (`Project_ID`);

--
-- Indexes for table `rfq_project_2020`
--
ALTER TABLE `rfq_project_2020`
  ADD PRIMARY KEY (`Project_ID`),
  ADD UNIQUE KEY `0001` (`Project_No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leporung_pro_employee_details_2020`
--
ALTER TABLE `leporung_pro_employee_details_2020`
  MODIFY `Project_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `leporung_pro_supplier_details_2020`
--
ALTER TABLE `leporung_pro_supplier_details_2020`
  MODIFY `Project_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `purchase_order_prices_2020`
--
ALTER TABLE `purchase_order_prices_2020`
  MODIFY `Project_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `purchase_order_projects_2020`
--
ALTER TABLE `purchase_order_projects_2020`
  MODIFY `Project_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rfq_products_2020`
--
ALTER TABLE `rfq_products_2020`
  MODIFY `Project_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rfq_project_2020`
--
ALTER TABLE `rfq_project_2020`
  MODIFY `Project_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
