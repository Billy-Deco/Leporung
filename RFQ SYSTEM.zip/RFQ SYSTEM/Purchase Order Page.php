<?php
	session_start();
	$location = 'index.php';
	$location1 = 'Purchase Order Menu.php';
	$dbServer = 'localhost';
	$dbName = 'Leporung_Pro';
	
	//Input Variable
	$project_no = "";
	$rfq_project_no = '';
	$entity = '';
	$description = '';
	$request_Date = '';
	$deadline_Date = '';
	$error_message = "";
	
	
	if(isset($_SESSION['Username'])){
		
		//Code For Save Button
		if(isset($_POST['Save'])){
			
			//Project Number Entity
			if(isset($_POST['Project_No'])){
				$project_no = $_POST['Project_No'];
			}
			
			//RFQ Project Entity
			if(isset($_POST['RFQ_Project_No'])){
				$rfq_project_no = $_POST['RFQ_Project_No'];
			}
			
			//RFQ Project Entity
			if(isset($_POST['Entity'])){
				$entity = $_POST['Entity'];
			}
			
			//RFQ Project Description
			if(isset($_POST['Description'])){
				$description = $_POST['Description'];
			}
			
			//RFQ Project Request Date
			if(isset($_POST['Request_Date'])){
				$request_Date = $_POST['Request_Date'];
			}
			
			//RFQ Project Deadline Date
			if(isset($_POST['Deadline_Date'])){
				$deadline_Date = $_POST['Deadline_Date'];
			}
			
			//------------------------Input Validation-------------------
			
			//Validate Project Number
			if(!empty($project_no)){
				$validProject_No = true;
			}else{
				$validProject_No = false;
			}
			
			//Validate Project Number
			if(!empty($rfq_project_no)){
				$validRFQ_Project_No = true;
			}else{
				$validRFQ_Project_No = false;
			}
			
			//Validate Entity
			if(!empty($entity)){
				$validEntity = strValidate($entity);
			}else{
				$error_message = "Required Entity Field.";
			}
			
			//Validate Description
			if(!empty($description)){
				$validDesc = true;
			}else{
				$validDesc = false;
			}
			
			//Validate Request Date
			if(!empty($request_Date)){
				$validRequest = validateDate($request_Date);
			}else{
				$error_message = "Required Request Date Field.";
			}
			
			//Validate Deadline Date
			if(!empty($deadline_Date)){
				$validRequest = validateDate($deadline_Date);
				if($validRequest){
					$expired = expiredProject($deadline_Date);
				}else{
					$error_message = "Project Already Expired.";
				}
			}else{
				$error_message = "Required Request Date Field.";
			}
			
			//database
			$conn = mysqli_connect($dbServer, 'root', 'TeeRay.1', $dbName);
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
			
			$sql = "SELECT * FROM leporung_pro_employee_details_2020";
			$results = mysqli_query($conn, $sql);
			$resultCheck = mysqli_num_rows($results);
				
			if($resultCheck > 0){
				
				while($row = mysqli_fetch_assoc($results)){
				
				if(($row['Deadline_Date'] == $deadline_Date) && ($row['Description'] == $description) && ($row['Project_No'] == $project_no) && ($row['Request_Date'] == $request_Date) && ($row['RFQ_Project_No'] == $rfq_project_no) && ($row['Entity'] == $entity) ){
					$save = false;
				}else{
					$save = true;
				}
			}
				
			}else{
			$save = true;
			}
			
			if($save){
					//mysql_select_db("leporung_db", $connect);
				$sql = "INSERT INTO leporung_pro.purchase_order_projects_2020
					(Deadline_Date, Description, Project_No, Request_Date, RFQ_Project_No, Supplier)
					VALUES('".$deadline_Date."', '".$description."', '".$project_no."', '".$request_Date."',  '".$rfq_project_no."',  '".$entity."' )";
				$sql2 = "SELECT * FROM rfq_project_2020";
			
				$resultsSave = mysqli_query($conn, $sql);
				
				if($resultsSave){
					$error_message = "Record Saved Successfully.";
					mysqli_close();
				}else{
					$error_message = "Record Not Saved.";
					//$error_message = $deadline_Date. " " .$description. " " .$project_no. " " .$request_Date. " " .$rfq_project_no. " " .$entity;
					mysqli_close($conn);
				}
			}else{
				$error_message = "Record Already Exists.";
			} 
			
		}
		
		//Preview Button Pressed
		if(isset($_POST['Clear All'])){
			
		}
		
		//Back Button Pressed
		if(isset($_POST['Back'])){
			
			header('Location:' .$location1);
			
		}
		
//========================================End Of Code==============================================================		
	}else{
		header('Location:' .$location);	
	}
	
//------------------------------------------------Validation Functions---------------------------------------------------------------------------
	//Function to Validate String Inputs
	function strValidate($strValue){
		$strValid = false;
		
		if (preg_match("/^[a-zA-Z ]+$/",$strValue)){
			$strValid = true;
		}else{
			$strValid = false;	
		}
		
		return $strValid;
	}
	
	//Function to Validate Digit inputs
	function dgtValidate($dgtValue){
		$dgtValid = false;
		
		if (preg_match("/^[0-9]*$/",$dgtValue)){
			$dgtValid = true;
		}else{
			$dgtValid = false;	
		}
		
		return $dgtValid;
	}
	
	//Function to Validate date Input
	function validateDate($value){
		$dateValid = false;
		
		if(date('Y/m/d', strtotime($value)) == $value){
			$dateValid = true;
		}else{
			$dateValid = false;	
		}
		
		return $dateValid;
	}
	
	//Function to Determine Expiration
	function expiredProject($date){
		$today = strtotime(date('Y/m/d'));
		$deadline_date = strtotime($date);
		
		if($today > $deadline_date)//check whether the deadline has passed
		{
			$expired = true;
		}
		else if($today == $deadline_date)
		{
			$expired = false;
		}
		else
		{
			$expired = false;
		}
		
		return $expired;
	}
	
	//Function for Invalid Dates
	function datesValid($req_date, $due_date){
		
		$start_date = strtotime($req_date);
		$end_date = strtotime($due_date);
		
		if(($end_date) > ($start_date)){
			$datesValid = true;	
		}else{
			$datesValid = false;	
		}
		
		return $datesValid;
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	
	<div id="Page">
    	<!--Logo Div Properties-->
        <div id="Heading">
			<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
        	<div>NEW PURCHASE ORDER PROJECT</div>
        </div>
        
        <!--View RFQ Properties-->
        <div id="Division">
        	<form action="Purchase Order Page.php" method="post">
            	<table align="center">
                	<tr>
						<td colspan="2" id="tableHeader"><?php echo $_SESSION["Username"]; ?></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><img src="images/Admin_PNG.png" id="Admin_Image" alt="Admin_Image" width="150px" height="100px"></td>
					</tr>
					<tr>
                    	<td id="indexLabel">Project Number: </td>
                        <td><input type="text" name="Project_No" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">RFQ Project Number: </td>
                        <td><input type="text" name="RFQ_Project_No" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Supplier: </td>
                        <td><input type="text" name="Entity" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Description: </td>
                        <td><input type="text" name="Description" id="inputCSS" size="30"></p></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Request Date: </td>
						<td><input type="text" name="Request_Date" size="12" id="inputCSS" placeholder="(YYYY/MM/DD)"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Deadline Date: </td>
                        <td><input type="text" name="Deadline_Date" size="12" id="inputCSS" placeholder="(YYYY/MM/DD)"></td>
                    </tr>
					<tr>
						<td colspan="2" align="center"><?php echo $error_message; ?></td>
					</tr>
                </table>
				
				<table  align="center">
					<tr>
						<td><input type="submit" name="Save" value="Save" id="button">
						<input type="reset" name="Clear All" value="Clear All" id="button"/>
						<input type="submit" name="Back" value="Back" id="button"/></td>
					</tr>
				</table>
			</form>
        </div>
        
        <!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div>
</body>
</html>
