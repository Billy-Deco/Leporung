<?php

	session_start();
	$location1 = 'Purchase Order Menu.php';
	$location2 = 'index.php';
	$dbServer = 'localhost';
	$dbName = 'Leporung_Pro';
	
	$entity = '';
	$description = '';
	$deadline_Date = '';
	$completion_Date = '';
	$error_message = '';
	$display_message_stat = array();
	
	$project_no = '';
	$project_no_S = '';
	
	$product_1 = '';
	$product_2 = '';
	$product_3 = '';
	$product_4 = '';
	$product_5 = '';
	$product_6 = '';
	$product_7 = '';
	$product_8 = '';
	$product_9 = '';
	$product_10 = '';
	$product_11 = '';
	$product_12 = '';
	$product_13 = '';
	$product_14 = '';
	$product_15 = '';
	
	$quantity_1 = '';
	$quantity_2 = '';
	$quantity_3 = '';
	$quantity_4 = '';
	$quantity_5 = '';
	$quantity_6 = '';
	$quantity_7 = '';
	$quantity_8 = '';
	$quantity_9 = '';
	$quantity_10 = '';
	$quantity_11 = '';
	$quantity_12 = '';
	$quantity_13 = '';
	$quantity_14 = '';
	$quantity_15 = '';
	
	if(isset($_POST['Search'])){
			
		if(isset($_POST['Project_No_S']) && !empty($_POST['Project_No_S'])){
				
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$project_no_S = $_POST['Project_No_S'];
					
			$sql1 = "SELECT * FROM rfq_project_2020 WHERE Project_No = '$project_no_S'";
			$sql2 = "SELECT * FROM rfq_products_2020 WHERE Project_No = '$project_no_S'";
			
			$result1 = mysqli_query($conn, $sql1);
			$result2 = mysqli_query($conn, $sql2);
			
			$resultCheck1 = mysqli_num_rows($result1);
			$resultCheck2 = mysqli_num_rows($result2);
				
			if($resultCheck1 > 0){
					
				while($row = mysqli_fetch_assoc($result1)){
					
					$entity = $row["Entity"];
					$description = $row["Description"];
					$deadline_Date = $row["Deadline_Date"];
					$completion_Date = $row["Completion_Date"];
					
					if($resultCheck2 > 0){
						
						while($row2 = mysqli_fetch_assoc($result2)){
							
							$product_1 = $row2["Product_1"];
							$product_2 = $row2["Product_2"];
							$product_3 = $row2["Product_3"];
							$product_4 = $row2["Product_4"];
							$product_5 = $row2["Product_5"];
							$product_6 = $row2["Product_6"];
							$product_7 = $row2["Product_7"];
							$product_8 = $row2["Product_8"];
							$product_9 = $row2["Product_9"];
							$product_10 = $row2["Product_10"];
							$product_11 = $row2["Product_11"];
							$product_12 = $row2["Product_12"];
							$product_13 = $row2["Product_13"];
							$product_14 = $row2["Product_14"];
							$product_15 = $row2["Product_15"];
							
							$quantity_1 = $row2["Quantity_1"];
							$quantity_2 = $row2["Quantity_2"];
							$quantity_3 = $row2["Quantity_3"];
							$quantity_4 = $row2["Quantity_4"];
							$quantity_5 = $row2["Quantity_5"];
							$quantity_6 = $row2["Quantity_6"];
							$quantity_7 = $row2["Quantity_7"];
							$quantity_8 = $row2["Quantity_8"];
							$quantity_9 = $row2["Quantity_9"];
							$quantity_10 = $row2["Quantity_10"];
							$quantity_11 = $row2["Quantity_11"];
							$quantity_12 = $row2["Quantity_12"];
							$quantity_13 = $row2["Quantity_13"];
							$quantity_14 = $row2["Quantity_14"];
							$quantity_15 = $row2["Quantity_15"];
						}
					}
					
				}

				mysqli_close($conn);
					
			}else{
				$error_message = "There are no records for " . $project_no_S . " search.";
			}
		}else{
			$error_message = "Please enter Project Number In Search Column.";
		}
	}
	
	//Code For Edit Button
	if(isset($_POST["Edit"])){
		
		$project_no = $_POST["Project_No"];
		$project_no_S = $_POST["Project_No"];
		$entity = $_POST["Entity"];
		$description = $_POST["Description"];
		$deadline_Date = $_POST["Deadline_Date"];
		$completion_Date = $_POST["Completion_Date"];
		
		//Product Variables
		$product_1 = $_POST["PD1"];
		$product_2 = $_POST["PD2"];
		$product_3 = $_POST["PD3"];
		$product_4 = $_POST["PD4"];
		$product_5 = $_POST["PD5"];
		$product_6 = $_POST["PD6"];
		$product_7 = $_POST["PD7"];
		$product_8 = $_POST["PD8"];
		$product_9 = $_POST["PD9"];
		$product_10 = $_POST["PD10"];
		$product_11 = $_POST["PD11"];
		$product_12 = $_POST["PD12"];
		$product_13 = $_POST["PD13"];
		$product_14 = $_POST["PD14"];
		$product_15 = $_POST["PD15"];
		
		//Quantity Variables
		$quantity_1 = $_POST["PQ1"];
		$quantity_2 = $_POST["PQ2"];
		$quantity_3 = $_POST["PQ3"];
		$quantity_4 = $_POST["PQ4"];
		$quantity_5 = $_POST["PQ5"];
		$quantity_6 = $_POST["PQ6"];
		$quantity_7 = $_POST["PQ7"];
		$quantity_8 = $_POST["PQ8"];
		$quantity_9 = $_POST["PQ9"];
		$quantity_10 = $_POST["PQ10"];
		$quantity_11 = $_POST["PQ11"];
		$quantity_12 = $_POST["PQ12"];
		$quantity_13 = $_POST["PQ13"];
		$quantity_14 = $_POST["PQ14"];
		$quantity_15 = $_POST["PQ15"];
		
		//Update Entity
		if(!empty($project_no) && !empty($entity)){
			
			$entityCheck = strValidate($entity);
			
			if($entityCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$sql = "UPDATE rfq_project_2020
						SET Entity = '$entity'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
				
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $entity . " record.";
				}
			}
		}
		
		//Update Description
		if(!empty($project_no) && !empty($description)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_project_2020
					SET Description = '$description'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $description . " record.";
			}
		}
		
		//Update Deadline Date
		if(!empty($project_no) && !empty($deadline_Date)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_project_2020
					SET Deadline_Date = '$deadline_Date'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $deadline_Date . " record.";
			}
		}
		
		//Update Completion Date
		if(!empty($project_no) && !empty($completion_Date)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_project_2020
					SET Completion_Date = '$completion_Date'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $completion_Date . " record.";
			}
		}
		
		//Update Product 1 
		if(!empty($project_no) && !empty($product_1)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_1 = '$product_1'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_1 . " record.";
			}
		}
		
		//Update Quantity 1 Record
		if(!empty($project_no) && !empty($quantity_1)){
			
			$qtyCheck = dgtValidate($quantity_1);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_1 = '$quantity_1'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_1 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 2 
		if(!empty($project_no) && !empty($product_2)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_2 = '$product_2'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_2 . " record.";
			}
		}
		
		//Update Quantity 2 Record
		if(!empty($project_no) && !empty($quantity_2)){
			
			$qtyCheck = dgtValidate($quantity_2);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_2 = '$quantity_2'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_2 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 3 
		if(!empty($project_no) && !empty($product_3)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_3 = '$product_3'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_3 . " record.";
			}
		}
		
		//Update Quantity 3 Record
		if(!empty($project_no) && !empty($quantity_3)){
			
			$qtyCheck = dgtValidate($quantity_3);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_3 = '$quantity_3'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_3 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 4 
		if(!empty($project_no) && !empty($product_4)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_4 = '$product_4'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_4 . " record.";
			}
		}
		
		//Update Quantity 4 Record
		if(!empty($project_no) && !empty($quantity_4)){
			
			$qtyCheck = dgtValidate($quantity_4);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_4 = '$quantity_4'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_4 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 5 
		if(!empty($project_no) && !empty($product_5)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_5 = '$product_5'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_5 . " record.";
			}
		}
		
		//Update Quantity 5 Record
		if(!empty($project_no) && !empty($quantity_5)){
			
			$qtyCheck = dgtValidate($quantity_5);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_5 = '$quantity_5'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_5 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 6 
		if(!empty($project_no) && !empty($product_6)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_6 = '$product_6'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_6 . " record.";
			}
		}
		
		//Update Quantity 6 Record
		if(!empty($project_no) && !empty($quantity_6)){
			
			$qtyCheck = dgtValidate($quantity_6);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_6 = '$quantity_6'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_6 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 7 
		if(!empty($project_no) && !empty($product_7)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_7 = '$product_7'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_7 . " record.";
			}
		}
		
		//Update Quantity 7 Record
		if(!empty($project_no) && !empty($quantity_7)){
			
			$qtyCheck = dgtValidate($quantity_7);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_7 = '$quantity_7'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_7 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 8 
		if(!empty($project_no) && !empty($product_8)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_8 = '$product_8'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_8 . " record.";
			}
		}
		
		//Update Quantity 8 Record
		if(!empty($project_no) && !empty($quantity_8)){
			
			$qtyCheck = dgtValidate($quantity_8);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_8 = '$quantity_8'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_1 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 9 
		if(!empty($project_no) && !empty($product_9)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_9 = '$product_9'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_9 . " record.";
			}
		}
		
		//Update Quantity 9 Record
		if(!empty($project_no) && !empty($quantity_9)){
			
			$qtyCheck = dgtValidate($quantity_9);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_9 = '$quantity_9'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_9 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 10 
		if(!empty($project_no) && !empty($product_10)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_10 = '$product_10'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_10 . " record.";
			}
		}
		
		//Update Quantity 10 Record
		if(!empty($project_no) && !empty($quantity_10)){
			
			$qtyCheck = dgtValidate($quantity_10);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_10 = '$quantity_10'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_10 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 11 
		if(!empty($project_no) && !empty($product_11)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_11 = '$product_11'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_11 . " record.";
			}
		}
		
		//Update Quantity 11 Record
		if(!empty($project_no) && !empty($quantity_11)){
			
			$qtyCheck = dgtValidate($quantity_11);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_11 = '$quantity_11'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_11 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 12 
		if(!empty($project_no) && !empty($product_12)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_12 = '$product_12'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_12 . " record.";
			}
		}
		
		//Update Quantity 12 Record
		if(!empty($project_no) && !empty($quantity_12)){
			
			$qtyCheck = dgtValidate($quantity_12);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_12 = '$quantity_12'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_12 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 13 
		if(!empty($project_no) && !empty($product_13)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_13 = '$product_13'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_13 . " record.";
			}
		}
		
		//Update Quantity 13 Record
		if(!empty($project_no) && !empty($quantity_13)){
			
			$qtyCheck = dgtValidate($quantity_13);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_13 = '$quantity_13'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_13 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 14 
		if(!empty($project_no) && !empty($product_14)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_14 = '$product_14'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_14 . " record.";
			}
		}
		
		//Update Quantity 14 Record
		if(!empty($project_no) && !empty($quantity_14)){
			
			$qtyCheck = dgtValidate($quantity_14);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_14 = '$quantity_14'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_14 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Update Product 15 
		if(!empty($project_no) && !empty($product_15)){
			
			$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
			if(!$conn){
				$error_message = 'Cannot Connect to Database.';
				die('Connection Failed.');
			}
				
			$sql = "UPDATE rfq_products_2020
					SET Product_15 = '$product_15'
					WHERE Project_No = '$project_no'";
					
			$result = mysqli_query($conn, $sql);
				
			if($result){
				$error_message = "Record Updated Successfully";
			}else{
				$error_message = "Could Not Update". $product_15 . " record.";
			}
		}
		
		//Update Quantity 15 Record
		if(!empty($project_no) && !empty($quantity_15)){
			
			$qtyCheck = dgtValidate($quantity_15);
			
			if($qtyCheck){
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
			
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
					
				$sql = "UPDATE rfq_products_2020
						SET Quantity_15 = '$quantity_15'
						WHERE Project_No = '$project_no'";
						
				$result = mysqli_query($conn, $sql);
					
				if($result){
					$error_message = "Record Updated Successfully";
				}else{
					$error_message = "Could Not Update". $quantity_15 . " record.";
				}
				
			}else{
				
			}
		}
		
		//Empty fields
		if(empty($_POST["Project_No"]) && empty($_POST["Entity"]) && empty($_POST["Description"]) && empty($_POST["Deadline_Date"]) && empty($_POST["Completion_Date"]) && empty($_POST["PD1"]) && empty($_POST["PQ1"]) && empty($_POST["PD2"]) && empty($_POST["PQ2"]) && empty($_POST["PD3"]) && empty($_POST["PQ3"]) && empty($_POST["PD4"]) && empty($_POST["PQ4"]) && empty($_POST["PD5"]) && empty($_POST["PQ5"]) && empty($_POST["PD6"]) && empty($_POST["PQ6"]) && empty($_POST["PD7"]) && empty($_POST["PQ7"]) && empty($_POST["PD8"]) && empty($_POST["PQ8"]) && empty($_POST["PD9"]) && empty($_POST["PQ9"]) && empty($_POST["PD10"]) && empty($_POST["PQ10"]) && empty($_POST["PD11"]) && empty($_POST["PQ11"]) && empty($_POST["PD12"]) && empty($_POST["PQ12"]) && empty($_POST["PD13"]) && empty($_POST["PQ13"]) && empty($_POST["PD14"]) && empty($_POST["PQ14"]) && empty($_POST["PD15"]) && empty($_POST["PQ15"])){
			
			$error_message = "Please Enter Project Number To Edit.";
		}
	}
	
	if(isset($_POST["Clear All"])){
		
		$project_no = "";
		$project_no_S = "";
		$entity = "";
		$description = "";
		$deadline_Date = "";
		$completion_Date = "";
		
		//Product Variables
		$product_1 = "";
		$product_2 = "";
		$product_3 = "";
		$product_4 = "";
		$product_5 = "";
		$product_6 = "";
		$product_7 = "";
		$product_8 = "";
		$product_9 = "";
		$product_10 = "";
		$product_11 = "";
		$product_12 = "";
		$product_13 = "";
		$product_14 = "";
		$product_15 = "";
		
		//Quantity Variables
		$quantity_1 = "";
		$quantity_2 = "";
		$quantity_3 = "";
		$quantity_4 = "";
		$quantity_5 = "";
		$quantity_6 = "";
		$quantity_7 = "";
		$quantity_8 = "";
		$quantity_9 = "";
		$quantity_10 = "";
		$quantity_11 = "";
		$quantity_12 = "";
		$quantity_13 = "";
		$quantity_14 = "";
		$quantity_15 = "";
	}
	
	if(isset($_POST["Back"])){
		
		header('Location:' .$location1);
		
	}
	
	//-------------------------------functions-----------------------------------
	function daysLeft($date){
		
		$td = date("Y-m-d");
		$today = strtotime($td);
		$deadline = strtotime($date);
		
		$daysLeft = floor(($deadline - $today)/60/60/24);
		
		return $daysLeft;
	}
	
	//Function to Determine Progress Status
	function progress_Status($days,$complete){
		
		$progress = '';
		$completion = date('Y-m-d', strtotime($complete));
		
		if($days == 0 && empty($complete)){
			$progress = "Due Today";
		}else if($days > 0 && empty($complete)){
			$progress = "In Progress";
		}else if($days < 0 && empty($complete)){
			$progress = "Incomplete";
		}else if($days >= 0 && !empty($complete)){
			$progress = "Completed";
		}
		
		return $progress;
	}
	
	//Function to Validate Digit inputs
	function dgtValidate($dgtValue){
		$dgtValid = false;
		
		if (preg_match("/^[0-9]*$/",$dgtValue)){
			$dgtValid = true;
		}else{
			$dgtValid = false;	
		}
		
		return $dgtValid;
	}

	//Function to Validate String Inputs
	function strValidate($strValue){
		$strValid = false;
		
		if (preg_match("/^[a-zA-Z ]+$/",$strValue)){
			$strValid = true;
		}else{
			$strValid = false;	
		}
		
		return $strValid;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	<div id="Page">
    	
       <!--Logo Div Properties-->
		<div id="Heading">
			<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
			<div>EDIT PURCHASE ORDER PROJECT</div>
		</div>
        
       	<!--Display Division-->
        <div id="Division">
        	<form action="Edit RFQ Page.php" method="post">
            	<table align="center">
                	<tr>
						<td colspan="2" id="tableHeader"><?php echo $_SESSION["Username"]; ?></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><img src="images/Admin_PNG.png" id="Admin_Image" alt="Admin_Image" width="150px" height="100px"></td>
					</tr>
					<tr>
                    	<td id="indexLabel">Project Number: </td>
                        <td colspan="5"><input type="text" name="Project_No_S" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td colspan="6" align="center"><input type="submit" name="Search" value="Search" id="button"></td>
                    </tr>
				</table>
			</form>
		</div>
		
		<div id="Division">
			<form action="Edit Purchase Order Page.php" method="post">
				<table align="center">
					<tr>
                    	<td id="indexLabel">Project Number: </td>
                        <td colspan="5"><input type="text" name="Project_No" id="inputCSS" size="30" value="<?php echo $project_no_S; ?>"></td>
                    </tr>
					<tr>
                    	<td id="indexLabel">RFQ Project Number: </td>
                        <td colspan="5"><input type="text" name="RFQ_Project_No" id="inputCSS" size="30" value="<?php echo $project_no_S; ?>"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Supplier: </td>
                        <td colspan="5"><input type="text" name="Entity" id="inputCSS" size="30" value="<?php echo $entity; ?>"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Description: </td>
                        <td colspan="5"><input type="text" name="Description" id="inputCSS" size="30" value="<?php echo ($description); ?>"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Deadline Date: </td>
                        <td><input type="text" name="Deadline_Date" size="12" id="inputCSS" placeholder="(YYYY/MM/DD)"  value="<?php echo ($deadline_Date); ?>"></td>
					</tr>
					<tr>
                    	<td id="indexLabel">Completion Date: </td>
                        <td><input type="text" name="Completion_Date" size="12" id="inputCSS" placeholder="(YYYY/MM/DD)" value="<?php echo ($completion_Date); ?>"></td>
					</tr>
					<tr>
                    	<td colspan="6" align="center"></td>
                    </tr>
				</table>
			
			<!--Product Edit Inputs-->
				<table align="center" class="table">
					<tr>
						<td id='tableHeader'>Item #</td>
						<td id='tableHeader'>Product Description</td>
						<td id='tableHeader'>Qty</td>
						<td id='tableHeader'>Item Price</td>
					</tr>
					<tr>
						<td align="center">1.</td>
						<td><input type="text" name="PD1" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ1" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP1" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">2.</td>
						<td><input type="text" name="PD2" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ2" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP2" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">3.</td>
						<td><input type="text" name="PD3" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ3" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP3" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">4.</td>
						<td><input type="text" name="PD4" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ4" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP4" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">5.</td>
						<td><input type="text" name="PD5" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ5" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP5" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">6.</td>
						<td><input type="text" name="PD6" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ6" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP6" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">7.</td>
						<td><input type="text" name="PD7" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ7" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP7" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">8.</td>
						<td><input type="text" name="PD8" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ8" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP8" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">9.</td>
						<td><input type="text" name="PD9" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ9" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP9" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td align="center">10.</td>
						<td><input type="text" name="PD10" class="P_Desc" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PQ10" class="unit" value="<?php //echo $project_no_S; ?>"/></td>
						<td><input type="text" name="PUP10" class="unitPrice" value="<?php //echo $project_no_S; ?>"/></td>
					</tr>
					<tr>
						<td colspan="3" align="center" id="buttonholder"><input type="submit" name="Save" value="Save" id="button">
						<input type="reset" name="Clear All" value="Clear All" id="button"/>
						<input type="submit" name="Back" value="Back" id="button"/></td>
					</tr>
				</table>
			</form>
        </div>
        
		<!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div>
</body>
</html>