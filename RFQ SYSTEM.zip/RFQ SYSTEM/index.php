<?php
	$user = "admin";
	$pass = "admin";
	$location1 = "Main Menu.php";
	$location2 = "index.php";
	$error_message = "";

	if(isset($_SESSION['Username'])){
		//header('Location: RFQ Page.html');
	}else{
		if(isset($_POST['Login'])){
			$username = $_POST['Username'];
			$password = $_POST['Password'];
			
			if(isset($_POST['Username']) && isset($_POST['Password'])){
				if(!empty($username)){
					if(!empty($password)){
						if($username == $user && $password == $pass){
							session_start();
							$_SESSION['Username'] = $username;
							$_SESSION['Password'] = $password;
							header('Location:' .$location1);
							//echo "<script>Location.href='RFQ Page.php'<script>";
							
						}else{
							$error_message = 'Incorrect Username and Password';	
							$_SESSION['Username'] = "";
						}
					}else{
						$error_password = "Incorrect Username and Password";
						$_SESSION['Username'] = "";	
					}
				}else{
					$error_message = "Required Username";
					$_SESSION['Username'] = "";	
				}
			}else{
				$error_message = "Required Username and Password";
				$_SESSION['Username'] = "";
			}	
		}
	}
?>





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	<div id="Page">

		<div id="Division">
			<!--Logo Div Properties-->
			<div id="Heading">
				<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
				<div>NEW RFQ PROJECT</div>
			</div>
			
        	<div id="Login_Holder">
				<form method="POST" action="index.php">
				
					<table align="center">
						<tr>
							<td align="center" colspan="2"><img src="images/Admin_PNG.png" id="index_Admin_Image" alt="Admin_Image" width="200px" height="150px"></td>
						</tr>
						<tr>
							<td><label id="indexLabel">Username:</label><br>
							<input type="text" name="Username" id="inputCSS"/></td>
						</tr>
						<tr>
							<td><label id="indexLabel">Password:</label><br>
							<input type="password" name="Password" id="inputCSS"></td>
						</tr>
						<tr>
							<td align="center"><input type="submit" name="Login" value="Login" id="login_button"/>
							<input type="reset" name="Clear" value="Clear" id="login_button"/>
							<p id=""><?php echo $error_message; ?></p></td>
						</tr>
					</table>
				</form>
			</div>
			
        </div>
		
		 <!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div> 
</body>
</html>

