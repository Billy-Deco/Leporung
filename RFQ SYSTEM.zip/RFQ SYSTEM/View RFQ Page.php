<?php
	session_start();
	$location = 'index.php';
	$locationH = 'View RFQ Page.php';
	$location1 = 'RFQ Sub Menu.php';
	$dbServer = 'localhost';
	$dbName = 'Leporung_Pro';
	
	
	$display_message = '';
	$error_message = '';
	$x = 0;
	$resultCheck = 0;
	$defaultStat = "None";
	$display_message_stat = array();
	
	if(isset($_SESSION['Username'])){
		
		//Search Button Initiated
		if(isset($_POST['Save'])){
			
			//Project Number Search Input
			if(isset($_POST['Project_No']) && !empty($_POST['Project_No']) && empty($_POST['Entity']) && empty($_POST['Description']) && empty($_POST['Request_Date']) && empty($_POST['Deadline_Date']) && empty($_POST['Username']) && $_POST['Progress_Status'] == $defaultStat){
				
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$project_no = $_POST['Project_No'];
					
				$sql = "SELECT * FROM rfq_project_2020 WHERE Project_No = '$project_no'";
				
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
				
				if($resultCheck > 0){
					
						while($row = mysqli_fetch_assoc($result)){
							
							$days_left = daysLeft($row["Deadline_Date"]);
							$progress_Status = progress_Status($days_left, $row["Completion_Date"]);
							
							$display_message_stat[$x] = '<tr class="border">
															<td>' . $row["Project_No"] . '</td>
															<td>' . $row["Entity"] . '</td>
															<td>' . $row["Description"] . '</td>
															<td align="center">' . $row["Request_Date"] . '</td>
															<td align="center">' . $row["Deadline_Date"] . '</td>
															<td align="center" id="font_size">' . $progress_Status . ' (' . $days_left . ' days)' . '</td>
															<td align="center">' . $row["Username"] . '</td>
															<td align="center">' . $row["Completion_Date"] . '</td>
														</tr>';
							$x++;
						}

					mysqli_close($conn);
					
					}else{
						$error_message = "There are no records for " . $project_no . " search.";
					}
			}
			
			//Entity Search Input
			if(isset($_POST['Entity']) && !empty($_POST['Entity']) && empty($_POST['Project_No']) && empty($_POST['Description']) && empty($_POST['Request_Date']) && empty($_POST['Deadline_Date']) && empty($_POST['Username']) && $_POST['Progress_Status'] == $defaultStat){
				
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$entity = $_POST['Entity'];
					
				$sql = "SELECT * FROM rfq_project_2020 WHERE Entity = '$entity'";
				
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
				
				if($resultCheck > 0){
					
						while($row = mysqli_fetch_assoc($result)){
							
							$days_left = daysLeft($row["Deadline_Date"]);
							$progress_Status = progress_Status($days_left, $row["Completion_Date"]);
							
							$display_message_stat[$x] = '<tr>
															<td>' . $row["Project_No"] . '</td>
															<td>' . $row["Entity"] . '</td>
															<td>' . $row["Description"] . '</td>
															<td align="center">' . $row["Request_Date"] . '</td>
															<td align="center">' . $row["Deadline_Date"] . '</td>
															<td align="center" id="font_size">' . $progress_Status . ' (' . $days_left . ' days)' . '</td>
															<td align="center">' . $row["Username"] . '</td>
															<td align="center">' . $row["Completion_Date"] . '</td>
														</tr>';
							$x++;
						}

					mysqli_close($conn);
					
					}else{
						$error_message = "There are no records for " . $entity . " search.";
					}
			}
			
			//Description Search Input
			if(isset($_POST['Description']) && !empty($_POST['Description']) && empty($_POST['Project_No']) && empty($_POST['Entity']) && empty($_POST['Request_Date']) && empty($_POST['Deadline_Date']) && empty($_POST['Username']) && $_POST['Progress_Status'] == $defaultStat){
				
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$description = $_POST['Description'];
					
				$sql = "SELECT * FROM rfq_project_2020 WHERE Description = '$description'";
				
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
				
				if($resultCheck > 0){
					
						while($row = mysqli_fetch_assoc($result)){
							
							$days_left = daysLeft($row["Deadline_Date"]);
							$progress_Status = progress_Status($days_left, $row["Completion_Date"]);
							
							$display_message_stat[$x] = '<tr>
															<td>' . $row["Project_No"] . '</td>
															<td>' . $row["Entity"] . '</td>
															<td>' . $row["Description"] . '</td>
															<td align="center">' . $row["Request_Date"] . '</td>
															<td align="center">' . $row["Deadline_Date"] . '</td>
															<td align="center" id="font_size">' . $progress_Status . ' (' . $days_left . ' days)' . '</td>
															<td align="center">' . $row["Username"] . '</td>
															<td align="center">' . $row["Completion_Date"] . '</td>
														</tr>';
							$x++;
						}

					mysqli_close($conn);
					
					}else{
						$error_message = "There are no records for " . $description . " search.";
					}
			}
			
			//Request Date Search Input
			if(isset($_POST['Request_Date']) && !empty($_POST['Request_Date']) && empty($_POST['Project_No']) && empty($_POST['Entity']) && empty($_POST['Description']) && empty($_POST['Deadline_Date']) && empty($_POST['Username']) && $_POST['Progress_Status'] == $defaultStat){
				
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$req = $_POST['Request_Date'];
				$requestValid = validateDate($req);
				
				if($requestValid){
					$request_date = $req;
					$sql = "SELECT * FROM rfq_project_2020 WHERE Request_Date = '$request_date'";
					
					$result = mysqli_query($conn, $sql);
					$resultCheck = mysqli_num_rows($result);
					
					if($resultCheck > 0){
					
						while($row = mysqli_fetch_assoc($result)){
							
							$days_left = daysLeft($row["Deadline_Date"]);
							$progress_Status = progress_Status($days_left, $row["Completion_Date"]);
														
							$display_message_stat[$x] = '<tr>
															<td>' . $row["Project_No"] . '</td>
															<td>' . $row["Entity"] . '</td>
															<td>' . $row["Description"] . '</td>
															<td align="center">' . $row["Request_Date"] . '</td>
															<td align="center">' . $row["Deadline_Date"] . '</td>
															<td align="center" id="font_size">' . $progress_Status . ' (' . $days_left . ' days)' . '</td>
															<td align="center">' . $row["Username"] . '</td>
															<td align="center">' . $row["Completion_Date"] . '</td>
														</tr>';
							$x++;
						}

					mysqli_close($conn);
					
					}else{
						$error_message = "There are no records for " . $request_date . " search.";
					}
				
				}else{
					$error_message = "Invalid Date Format, Please use the required date Format (YYYY-MM-DD)";
				}
			}
			
			//Deadline Date Search Input
			if(isset($_POST['Deadline_Date']) && !empty($_POST['Deadline_Date']) && empty($_POST['Project_No']) && empty($_POST['Entity']) && empty($_POST['Description']) && empty($_POST['Request_Date']) && empty($_POST['Username']) && $_POST['Progress_Status'] == $defaultStat){
				
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$deadline = $_POST['Deadline_Date'];
				$deadlineValid = validateDate($deadline);
				
				if($deadlineValid){
					$deadline_date = $deadline;
					$sql = "SELECT * FROM rfq_project_2020 WHERE Deadline_Date = '$deadline_date'";
					
					$result = mysqli_query($conn, $sql);
					$resultCheck = mysqli_num_rows($result);
					
					if($resultCheck > 0){
					
						while($row = mysqli_fetch_assoc($result)){
							
							$days_left = daysLeft($row["Deadline_Date"]);
							$progress_Status = progress_Status($days_left, $row["Completion_Date"]);
							
							$display_message_stat[$x] = '<tr>
															<td>' . $row["Project_No"] . '</td>
															<td>' . $row["Entity"] . '</td>
															<td>' . $row["Description"] . '</td>
															<td align="center">' . $row["Request_Date"] . '</td>
															<td align="center">' . $row["Deadline_Date"] . '</td>
															<td align="center" id="font_size">' . $progress_Status . ' (' . $days_left . ' days)' . '</td>
															<td align="center">' . $row["Username"] . '</td>
															<td align="center">' . $row["Completion_Date"] . '</td>
														</tr>';
							$x++;
						}

					mysqli_close($conn);
					
					}else{
						$error_message = "There are no records for " . $deadline_date . " search.";
					}
				
				}else{
					$error_message = "Invalid Date Format, Please use the required date Format (YYYY-MM-DD)";
				}
			}
			
			//Progress Status Search Input
			if($_POST['Progress_Status'] != $defaultStat && empty($_POST['Project_No']) && empty($_POST['Entity']) && empty($_POST['Description']) && empty($_POST['Request_Date']) && empty($_POST['Username']) && empty($_POST['Deadline_Date'])){
				
				$progress = $_POST['Progress_Status'];
				
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
				if(!$conn){
					$display_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$sql = "SELECT * FROM rfq_project_2020";
					
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
						
				if($resultCheck > 0){
						
					while($row = mysqli_fetch_assoc($result)){
						
						$days_left = daysLeft($row["Deadline_Date"]);
						$progress_Status = progress_Status($days_left, $row["Completion_Date"]);
						
						if($progress == $progress_Status){
							
							$display_message_stat[$x] = '<tr>
															<td>' . $row["Project_No"] . '</td>
															<td>' . $row["Entity"] . '</td>
															<td>' . $row["Description"] . '</td>
															<td align="center">' . $row["Request_Date"] . '</td>
															<td align="center">' . $row["Deadline_Date"] . '</td>
															<td align="center" id="font_size">' . $progress_Status . ' (' . $days_left . ' days)' . '</td>
															<td align="center">' . $row["Username"] . '</td>
															<td align="center">' . $row["Completion_Date"] . '</td>
														</tr>';
							$x++;
						}else{
							$x++;
						}
					}

					mysqli_close($conn);
						
				}else{
					$error_message = "There are no records for " . $progress . " search.";
				}
			}
			
			//Username Search Input
			if(isset($_POST['Username']) && !empty($_POST['Username']) && empty($_POST['Entity']) && empty($_POST['Description']) && empty($_POST['Request_Date']) && empty($_POST['Deadline_Date']) && empty($_POST['Project_No']) && $_POST['Progress_Status'] == $defaultStat){
				
				$conn = mysqli_connect($dbServer, 'Bunny MD', 'Billy#20Deco', $dbName);
				if(!$conn){
					$error_message = 'Cannot Connect to Database.';
					die('Connection Failed.');
				}
				
				$user = $_POST['Username'];
					
				$sql = "SELECT * FROM rfq_project_2020 WHERE Username = '$user'";
				
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
				
				if($resultCheck > 0){
					
						while($row = mysqli_fetch_assoc($result)){
							
							$days_left = daysLeft($row["Deadline_Date"]);
							$progress_Status = progress_Status($days_left, $row["Completion_Date"]);
	
							$display_message_stat[$x] = '<tr>
															<td>' . $row["Project_No"] . '</td>
															<td>' . $row["Entity"] . '</td>
															<td>' . $row["Description"] . '</td>
															<td align="center">' . $row["Request_Date"] . '</td>
															<td align="center">' . $row["Deadline_Date"] . '</td>
															<td align="center" id="font_size">' . $progress_Status . ' (' . $days_left . ' days)' . '</td>
															<td align="center">' . $row["Username"] . '</td>
															<td align="center">' . $row["Completion_Date"] . '</td>
														</tr>';
							$x++;
						}

					mysqli_close($conn);
					
				}else{
					$error_message = "There are no records for " . $user . " search.";
				}
			}
			
			//Empty Search Fields
			if($_POST['Progress_Status'] == $defaultStat && empty($_POST['Project_No']) && empty($_POST['Entity']) && empty($_POST['Description']) && empty($_POST['Request_Date']) && empty($_POST['Username']) && empty($_POST['Deadline_Date'])){
				
				$error_message = "Please enter one of the search fields";
			}
		}
		
		//Back Button Pressed
		if(isset($_POST['Back'])){
			
			header('Location:' .$location1);
			
		}
		
	}else{
		header('Location:' .$location);	
	}
	
	//Function to Validate date Input
	function validateDate($value){
		$dateValid = false;
		
		if(date('Y-m-d', strtotime($value)) == $value){
			$dateValid = true;
		}else{
			$dateValid = false;	
		}
		
		return $dateValid;
	}
	
	//Function to Validate Number of days Left
	function daysLeft($date){
		
		$td = date("Y-m-d");
		$today = strtotime($td);
		$deadline = strtotime($date);
		
		$daysLeft = floor(($deadline - $today)/60/60/24);
		
		return $daysLeft;
	}
	
	//Function to Determine Progress Status
	function progress_Status($days,$complete){
		
		$progress = '';
		$completion = date('Y-m-d', strtotime($complete));
		
		if($days == 0 && empty($complete)){
			$progress = "Due Today";
		}else if($days > 0 && empty($complete)){
			$progress = "In Progress";
		}else if($days < 0 && empty($complete)){
			$progress = "Incomplete";
		}else if($days >= 0 && !empty($complete)){
			$progress = "Completed";
		}else if($days <=0 && !empty($complete)){
			$progress = "Completed";
		}
		
		return $progress;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	<div id="Page">
    	
        <!--Logo Div Properties-->
		<div id="Heading">
			<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
			<div>PURCHASE ORDER MENU</div>
		</div>
        
       	<!--Display Division-->
        <div id="Division">
        	<form action="View RFQ Page.php" method="post">
            	<table align="center">
                	<tr>
						<td colspan="2" id="tableHeader"><?php echo $_SESSION["Username"]; ?></td>
					</tr>
					<tr>
						<td align="center" colspan="2"><img src="images/Admin_PNG.png" id="Admin_Image" alt="Admin_Image" width="150px" height="100px"></td>
					</tr>
					<tr>
                    	<td id="indexLabel">Project Number: </td>
                        <td><input type="text" name="Project_No" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Entity/Supplier: </td>
                        <td><input type="text" name="Entity" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Description: </td>
                        <td><input type="text" name="Description" id="inputCSS" size="30"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Request Date: </td>
                        <td><input type="text" name="Request_Date" size="12" placeholder="(YYYY/MM/DD)" id="inputCSS"></td>
                    </tr>
                    <tr>
                    	<td id="indexLabel">Deadline Date: </td>
                        <td><input type="text" name="Deadline_Date" size="12" placeholder="(YYYY/MM/DD)" id="inputCSS"></td>
					</tr>
					<tr>
                    	<td id="indexLabel">Progress Status: </td>
                        <td>
							<select name="Progress_Status">
								<option>None</option>
								<option value="In Progress">In Progress</option>
								<option value="Completed">Completed</option>
								<option value="Incomplete">Incomplete</option>
								<option value="Due Today">Due Today</option>
							</select>
						</td>
					</tr>
					<tr>
                    	<td id="indexLabel">Username: </td>
                        <td><input type="text" name="Username" id="inputCSS" size="30"></td>
                    </tr>
					<tr>
                    	<td colspan="2"align="center"><?php echo  $error_message;?><td>
                    </tr>
				</table> 
				
				<table  align="center">
					<tr>
						<td><input type="submit" name="Save" value="Save" id="button">
						<input type="reset" name="Clear All" value="Clear All" id="button"/>
						<input type="submit" name="Back" value="Back" id="button"/></td>
					</tr>
				</table>
			</form>
        </div>

		<!--Display Division-->
        <div id="Division">
        	<?php 
			echo "<table align='center' class='table'>
					<tr>
						<td id='tableHeader' width='20px'>Project No:</td>
						<td id='tableHeader' width='250px'>Entity</td>
						<td id='tableHeader' width='250px'>Description</td>
						<td id='tableHeader' width='100px'>Request_Date</td>
						<td id='tableHeader' width='100px'>Deadline_Date</td>
						<td id='tableHeader' width='100px'>Progress Status</td>
						<td id='tableHeader' width='150px'>Username</td>
						<td id='tableHeader' width='100px'>Completion_Date</td>
					</tr>";
				
			foreach($display_message_stat as $display_message){
				echo $display_message;
			} 
			
			echo "</table>";
			
			?>
        </div>
        
		<!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div>
</body>
</html>
