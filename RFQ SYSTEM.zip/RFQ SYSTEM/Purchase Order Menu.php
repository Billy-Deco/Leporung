<?php
	session_start();
	$location = 'index.php';
	$location1 = 'Purchase Order Page.php';
	$location2 = 'View RFQ Page.php';
	$location3 = 'Edit Purchase Order Page.php';
	$location4 = 'Main Menu.php';
	$dbServer = 'localhost';
	$dbName = 'Leporung_Pro';
	
	if(isset($_SESSION['Username'])){
		
		//NEW_PROJECT Button Pressed
		if(isset($_POST['NEW_PROJECT'])){
			
			header('Location:' .$location1);	
			
		}
		
		//SEARCH_PROJECT Button Pressed
		if(isset($_POST['SEARCH_PROJECT'])){
			
			header('Location:' .$location2);
			
		}
		
		//EDIT_PROJECT Button Pressed
		if(isset($_POST['EDIT_PROJECT'])){
			
			header('Location:' .$location3);
			
		}
		
		//Logout Button Pressed
		if(isset($_POST['Back'])){
			
			header('Location:' .$location4);
			
		}
		
//========================================End Of Code==============================================================		
	}else{
		header('Location:' .$location);	
	}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="LPSstyle.css" rel="stylesheet" type="text/css" />
<title>Untitled Document</title>
</head>

<body>
	
	<div id="Page">

		<!--Display Division-->
        <div id="Division">
        	
			<!--Logo Div Properties-->
			<div id="Heading">
				<img src="images/Logo 2.jpg" alt="Leporung Projects and Supply" width="60%" height="150px" id="Logo_Image"/>
				<div>PURCHASE ORDER MENU</div>
			</div>
			
			<form action="Purchase Order Menu.php" method="POST">
				<table align="center">
					<tr>
						<td width="350px" height="30px"><input type="submit" name="NEW_PROJECT" value="NEW PROJECT" id="button_css" height="100px"></td>
					</tr>
					<tr>
						<td width="350px" height="30px"><input type="submit" name="SEARCH_PROJECT" value="SEARCH PROJECT" id="button_css"></td>
					</tr>
					<tr>
						<td width="350px" height="30px"><input type="submit" name="EDIT_PROJECT" value="EDIT PROJECT" id="button_css"></td>
					</tr>
					<tr>
						<td width="350px" height="30px"><input type="submit" name="Back" value="BACK" id="button_css"></td>
					</tr>
				</table>
			</form>
			
        </div>
        
        <!--Footer Division-->
        <div id="F_Division">
        	
        </div>
    </div>
</body>
</html>
